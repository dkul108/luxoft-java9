module drug.storage
{
    requires storage;

//    provides com.storage.Storage with drugs.DrugStorage;
}