module automodule
{
    exports com.luxoft;
}