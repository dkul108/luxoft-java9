
module animals
{
    exports com.animals;
}