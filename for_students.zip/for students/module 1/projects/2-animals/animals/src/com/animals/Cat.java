package com.animals;

public class Cat
{
    private String name;

    public Cat(String name)
    {
        this.name = name;
    }

    public void voice()
    {
        System.out.println(name + ": Murrr....");
    }
}
