module employees
{
    requires animals;
}