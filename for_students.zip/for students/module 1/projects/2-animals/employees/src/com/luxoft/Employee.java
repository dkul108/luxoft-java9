package com.luxoft;

import com.animals.Cat;

public class Employee
{
    private String name;

    public Employee(String name)
    {
        this.name = name;
    }

    public void feed(Cat cat)
    {
        cat.voice();
    }
}
