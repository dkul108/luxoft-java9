package com.luxoft;

import com.animals.Cat;

public class Demo
{
    public static void main(String[] args)
    {
        Employee employee = new Employee("John");

        Cat cat = new Cat("Murzik");

        employee.feed(cat);
    }
}
