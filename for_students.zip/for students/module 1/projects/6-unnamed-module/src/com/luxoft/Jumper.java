package com.luxoft;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.JUnitCore;

public class Jumper
{
    public boolean canJump()
    {
        return true;
    }

    @Test
    public void jumpTest()
    {
        assertTrue(canJump());
    }

    public static void main(String[] args)
    {
        JUnitCore.main(Jumper.class.getName());
    }
}
