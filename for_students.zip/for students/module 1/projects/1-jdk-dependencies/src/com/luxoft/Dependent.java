package com.luxoft;

import java.util.logging.Logger;

public class Dependent
{
    public static final Logger logger = Logger.getLogger(Dependent.class.getName());

    public static void main(String[] args)
    {
        logger.info("I can't live alone.");
        logger.info("Give me at least java.util.logging.Logger");
    }
}
