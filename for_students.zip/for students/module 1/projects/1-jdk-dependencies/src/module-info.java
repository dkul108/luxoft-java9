module dependent
{
    requires java.logging;
}