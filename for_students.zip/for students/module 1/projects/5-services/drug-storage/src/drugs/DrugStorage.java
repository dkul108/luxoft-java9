package drugs;

import com.storage.Product;
import com.storage.Storage;

public class DrugStorage implements Storage
{
    @Override
    public Product get(int numberOfUnits)
    {
        System.out.println(numberOfUnits + " units of " + Product.DRUG + " requested.");
        return Product.DRUG;
    }
}
