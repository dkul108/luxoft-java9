module storage
{
    exports com.storage;
}