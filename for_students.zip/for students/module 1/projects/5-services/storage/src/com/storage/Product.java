package com.storage;

public enum Product
{
    DRUG
}
