package com.storage;

public interface Storage
{
    Product get(int numberOfUnits);
}
