module consumer
{
    requires storage;

    uses com.storage.Storage;
}