package com;

public class HiddenDealDemo
{
    public static void main(String[] args)
    {
        DrugDealer dealer = new DrugDealer();

        System.out.println("Hi, do you have something from me today?");
        dealer.get(100);
    }
}
