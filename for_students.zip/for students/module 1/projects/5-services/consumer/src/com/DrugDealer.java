package com;

import com.storage.Product;
import com.storage.Storage;

import java.util.Optional;
import java.util.ServiceLoader;

public class DrugDealer
{
    public Product get(int numberOfUnits)
    {
        ServiceLoader<Storage> loader = ServiceLoader.load(Storage.class);
        Optional<Storage> storage = loader.findFirst();

        if (storage.isPresent())
        {
            return storage.get().get(numberOfUnits);
        }

        throw new IllegalArgumentException("What, who do you think I am?");
    }
}
