module automodule
{
    exports com.luxoft;

    requires junit;
}