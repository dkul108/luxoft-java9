package com.father;

public class Father
{
    public Car buyCar()
    {
        return new Car();
    }
}
