package com.father;

public class Car
{
    @Override
    public String toString()
    {
        return "Mercedes";
    }
}
