
module father
{
    exports com.father
//            to daughter
            ;
}