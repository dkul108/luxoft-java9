
module daughter
{
    requires father;
}