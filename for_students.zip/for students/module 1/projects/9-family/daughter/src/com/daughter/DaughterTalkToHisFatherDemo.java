package com.daughter;

import com.father.Father;

public class DaughterTalkToHisFatherDemo
{
    public static void main(String[] args)
    {
        Father father = new Father();

        System.out.println("Daughter driving " + father.buyCar());
    }
}
