
module son
{
    requires father;
}