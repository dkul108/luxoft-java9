package com.son;

import com.father.Father;

public class SonTalkToHisFatherDemo
{
    public static void main(String[] args)
    {
        Father father = new Father();

        System.out.println("Son driving " + father.buyCar() + " uaaaaaaaa....");
    }
}
