module product
{
    exports com.product;
}