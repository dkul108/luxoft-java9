module shop
{
    requires product;
//    requires transitive product;

    exports com.shop;
}