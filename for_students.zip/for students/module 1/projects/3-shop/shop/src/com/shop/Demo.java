package com.shop;

import com.product.Product;

public class Demo
{
    public static void main(String[] args)
    {
        Shop shop = new Shop();
        shop.printTotalSales();

        shop.sell(Product.MEAT);

        shop.sell(Product.MILK);
        shop.sell(Product.EGG);

        shop.printTotalSales();
    }
}
