package com.shop;

import com.product.Product;
import java.util.ArrayList;
import java.util.List;

public class Shop
{
    private List<Product> products;

    public Shop()
    {
        this.products = new ArrayList<>();
    }

    public void sell(Product product)
    {
        products.add(product);
    }

    public Product sellRandomProduct()
    {
        products.add(Product.EGG);
        return Product.EGG;
    }

    public void printTotalSales()
    {
        double totalSales = products.stream()
                .mapToDouble(t -> t.getPrice())
                .sum();

        System.out.println("Total Sales: " + totalSales);
    }
}
