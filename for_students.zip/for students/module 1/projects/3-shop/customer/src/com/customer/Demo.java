package com.customer;

import com.product.Product;
import com.shop.Shop;

public class Demo
{
    public static void main(String[] args)
    {
        Shop shop = new Shop();

        Customer customer = new Customer("Ivan");

        Product product = customer.buyRandomProduct(shop);

        System.out.println(customer.getName() + " just bought " + product);
    }
}
