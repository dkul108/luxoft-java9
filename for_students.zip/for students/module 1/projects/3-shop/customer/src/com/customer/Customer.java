package com.customer;

import com.product.Product;
import com.shop.Shop;

public class Customer
{
    private String name;

    public Customer(String name)
    {
        this.name = name;
    }

    public Product buyRandomProduct(Shop shop)
    {
        return shop.sellRandomProduct();
    }

    public String getName()
    {
        return name;
    }
}
