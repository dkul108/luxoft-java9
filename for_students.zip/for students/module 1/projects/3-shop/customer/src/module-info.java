module customer
{
    requires shop;
    requires product;
}