package com.dealer;

import com.storage.Product;
import com.storage.StorageProvider;
import com.storage.impl.ProductStorage;

public class MilkDealerDemo
{
    public static void main(String[] args)
    {
        StorageProvider.getStorage().store(10);

        Product product = ((ProductStorage) StorageProvider.getStorage()).getProduct();
        System.out.println(product);
    }
}
