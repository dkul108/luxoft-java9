module dealer
{
    requires storage;
}