module storage
{
    exports com.storage;
    exports com.storage.impl;
}