package com.storage;

public interface Storage
{
    void store(int numberOfUnits);


}
