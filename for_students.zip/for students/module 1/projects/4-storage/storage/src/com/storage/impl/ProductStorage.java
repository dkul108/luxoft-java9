package com.storage.impl;

import com.storage.Product;
import com.storage.Storage;

public class ProductStorage implements Storage
{
    @Override
    public void store(int numberOfUnits)
    {
        System.out.println(numberOfUnits + " units of " + Product.MILK + " stored.");
    }

    public Product getProduct()
    {
        System.out.println("I'm not accessible via interface.");
        return Product.MILK;
    }
}
