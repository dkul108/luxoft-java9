package com.storage;

import com.storage.impl.ProductStorage;

public class StorageProvider
{
    public static Storage getStorage()
    {
        return new ProductStorage();
    }
}
