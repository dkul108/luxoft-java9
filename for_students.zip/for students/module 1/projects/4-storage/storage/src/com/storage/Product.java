package com.storage;

public enum Product
{
    MILK
}
